CREATE DATABASE IF NOT EXISTS ptero_store CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ptero_store;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('user','admin') DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE eggs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    icon VARCHAR(10) DEFAULT '🥚',
    description TEXT,
    nest VARCHAR(50),
    pterodactyl_egg_id INT,
    active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE plans (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ram INT NOT NULL,
    price INT NOT NULL,
    cpu INT NOT NULL,
    disk INT NOT NULL,
    swap INT NOT NULL,
    badge VARCHAR(20) DEFAULT '',
    active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE scripts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price INT NOT NULL,
    file_url VARCHAR(500),
    active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE servers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    url VARCHAR(200) NOT NULL,
    api_key VARCHAR(255) NOT NULL,
    status ENUM('active','maintenance') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    type ENUM('panel','script') NOT NULL,
    -- Panel fields
    hostname VARCHAR(100),
    username VARCHAR(50),
    panel_email VARCHAR(100),
    egg_id INT,
    ram INT,
    cpu INT,
    disk INT,
    swap INT,
    -- Script fields
    script_id INT,
    bot_name VARCHAR(100),
    bot_token VARCHAR(255),
    chat_id VARCHAR(50),
    -- Payment
    amount INT NOT NULL,
    fee INT NOT NULL,
    total INT NOT NULL,
    payment_method VARCHAR(20) DEFAULT 'qris',
    payment_number TEXT,
    status ENUM('pending','paid','active','completed','expired','cancelled') DEFAULT 'pending',
    -- Pterodactyl
    pterodactyl_server_id VARCHAR(50),
    server_id INT,
    -- Subscription
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    paid_at TIMESTAMP NULL,
    expires_at TIMESTAMP NULL,
    deleted_at TIMESTAMP NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (egg_id) REFERENCES eggs(id),
    FOREIGN KEY (script_id) REFERENCES scripts(id),
    FOREIGN KEY (server_id) REFERENCES servers(id)
);

-- Insert default admin
INSERT INTO users (name, email, password_hash, role) VALUES 
('Admin', 'admin@ptero.store', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- password: admin123

-- Insert default eggs
INSERT INTO eggs (name, icon, description, nest, pterodactyl_egg_id) VALUES
('Minecraft Java', '⛏️', 'Vanilla / Paper / Purpur', 'Minecraft', 1),
('Minecraft Bedrock', '🧱', 'PocketMine / Nukkit', 'Minecraft', 2),
('Node.js', '🟢', 'Express, Discord.js, etc', 'Node.js', 3),
('Python', '🐍', 'Flask, Django, aiogram', 'Python', 4),
('Rust', '⚙️', 'Rust server / app', 'Rust', 5),
('Go', '🔵', 'Go application', 'Go', 6),
('CS2 Server', '🔫', 'Counter-Strike 2 Dedicated', 'Source Engine', 7),
('GTA V / FiveM', '🚗', 'FiveM Server', 'Grand Theft Auto', 8),
('Terraria', '🌍', 'TShock Server', 'Terraria', 9);

-- Insert default plans
INSERT INTO plans (ram, price, cpu, disk, swap, badge) VALUES
(1, 7000, 100, 5120, 1024, ''),
(2, 12000, 150, 10240, 2048, ''),
(3, 17000, 200, 15360, 3072, ''),
(4, 22000, 250, 20480, 4096, 'POP'),
(6, 32000, 300, 30720, 6144, ''),
(8, 42000, 400, 40960, 8192, ''),
(12, 62000, 500, 61440, 12288, ''),
(16, 82000, 600, 81920, 16384, 'BEST');

-- Insert default scripts
INSERT INTO scripts (name, description, price, file_url) VALUES
('Bot Group Manager', 'Welcome, rules, anti-spam, auto delete, mute, ban, log channel', 35000, '#'),
('Bot Music Player', 'Play music from YouTube/Spotify, queue system, playlist', 45000, '#'),
('Bot Store / Payment', 'Jualan produk digital, invoice otomatis, QRIS integration', 75000, '#'),
('Bot Auto Forward', 'Auto forward pesan antar channel/group dengan filter', 25000, '#'),
('Bot AI ChatGPT', 'Integrasi OpenAI, custom personality, group & private chat', 55000, '#'),
('Bot Downloader', 'Download TikTok, Instagram, YouTube, Twitter media', 40000, '#');
