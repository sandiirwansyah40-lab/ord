<?php
// Run this via cron every hour: php /path/to/cron.php
require 'config.php';

$conn = getDB();
$now = date('Y-m-d H:i:s');

// Find expired panel orders
$stmt = $conn->prepare("SELECT o.*, s.url as server_url, s.api_key FROM orders o JOIN servers s ON o.server_id = s.id WHERE o.type = 'panel' AND o.status = 'active' AND o.expires_at < ? AND o.deleted_at IS NULL");
$stmt->bind_param("s", $now);
$stmt->execute();
$result = $stmt->get_result();

while ($order = $result->fetch_assoc()) {
    // Delete from Pterodactyl
    $ch = curl_init($order['server_url'] . '/api/application/servers/' . $order['pterodactyl_server_id']);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'DELETE');
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $order['api_key'],
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_exec($ch);
    curl_close($ch);

    // Mark as expired
    $stmt2 = $conn->prepare("UPDATE orders SET status = 'expired', deleted_at = NOW() WHERE id = ?");
    $stmt2->bind_param("i", $order['id']);
    $stmt2->execute();

    echo "Deleted server: " . $order['order_id'] . "
";
}

echo "Cron completed.
";
?>
