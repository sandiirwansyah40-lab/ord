<?php
header('Content-Type: application/json');
require 'config.php';

$conn = getDB();
$input = json_decode(file_get_contents('php://input'), true);

// Verify admin
$headers = getallheaders();
$token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');
$payload = verifyJWT($token);

if (!$payload || $payload['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Forbidden']);
    exit;
}

$action = $input['action'] ?? '';

if ($action === 'get_dashboard') {
    $stats = [
        'total_users' => $conn->query("SELECT COUNT(*) as c FROM users WHERE role = 'user'")->fetch_assoc()['c'],
        'total_orders' => $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'],
        'total_revenue' => $conn->query("SELECT COALESCE(SUM(total), 0) as c FROM orders WHERE status IN ('active', 'completed', 'paid')")->fetch_assoc()['c'],
        'active_servers' => $conn->query("SELECT COUNT(*) as c FROM orders WHERE type = 'panel' AND status = 'active'")->fetch_assoc()['c'],
    ];
    echo json_encode(['success' => true, 'stats' => $stats]);
}

elseif ($action === 'get_plans') {
    $plans = $conn->query("SELECT * FROM plans WHERE active = 1 ORDER BY ram")->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'plans' => $plans]);
}

elseif ($action === 'add_plan') {
    $ram = intval($input['ram']);
    $price = intval($input['price']);
    $cpu = intval($input['cpu']);
    $disk = intval($input['disk']);
    $swap = $ram * 1024;

    $stmt = $conn->prepare("INSERT INTO plans (ram, price, cpu, disk, swap) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiii", $ram, $price, $cpu, $disk, $swap);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'delete_plan') {
    $id = intval($input['id']);
    $stmt = $conn->prepare("UPDATE plans SET active = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'get_scripts') {
    $scripts = $conn->query("SELECT * FROM scripts WHERE active = 1 ORDER BY id")->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'scripts' => $scripts]);
}

elseif ($action === 'add_script') {
    $name = htmlspecialchars($input['name']);
    $desc = htmlspecialchars($input['description']);
    $price = intval($input['price']);
    $url = htmlspecialchars($input['file_url'] ?? '#');

    $stmt = $conn->prepare("INSERT INTO scripts (name, description, price, file_url) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssis", $name, $desc, $price, $url);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'delete_script') {
    $id = intval($input['id']);
    $stmt = $conn->prepare("UPDATE scripts SET active = 0 WHERE id = ?");
    $stmt->bind_param("i", $id);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'get_servers') {
    $servers = $conn->query("SELECT id, name, url, status FROM servers ORDER BY id")->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'servers' => $servers]);
}

elseif ($action === 'add_server') {
    $name = htmlspecialchars($input['name']);
    $url = htmlspecialchars($input['url']);
    $key = $input['api_key'];
    $status = $input['status'] ?? 'active';

    $stmt = $conn->prepare("INSERT INTO servers (name, url, api_key, status) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $name, $url, $key, $status);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'delete_server') {
    $id = intval($input['id']);
    $stmt = $conn->prepare("DELETE FROM servers WHERE id = ?");
    $stmt->bind_param("i", $id);
    echo json_encode(['success' => $stmt->execute()]);
}

elseif ($action === 'get_orders') {
    $orders = $conn->query("SELECT o.*, u.name as user_name, e.name as egg_name, s.name as script_name FROM orders o JOIN users u ON o.user_id = u.id LEFT JOIN eggs e ON o.egg_id = e.id LEFT JOIN scripts s ON o.script_id = s.id ORDER BY o.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'orders' => $orders]);
}

elseif ($action === 'get_users') {
    $users = $conn->query("SELECT u.*, (SELECT COUNT(*) FROM orders WHERE user_id = u.id) as order_count, (SELECT COALESCE(SUM(total), 0) FROM orders WHERE user_id = u.id AND status IN ('active','completed','paid')) as total_spent FROM users u ORDER BY u.created_at DESC")->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'users' => $users]);
}

elseif ($action === 'delete_order') {
    $orderId = $input['order_id'] ?? '';
    $stmt = $conn->prepare("DELETE FROM orders WHERE order_id = ?");
    $stmt->bind_param("s", $orderId);
    echo json_encode(['success' => $stmt->execute()]);
}
?>
