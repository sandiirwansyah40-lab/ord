<?php
header('Content-Type: application/json');
require 'config.php';

$conn = getDB();
$input = json_decode(file_get_contents('php://input'), true);

// Verify JWT
$headers = getallheaders();
$token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');
$payload = verifyJWT($token);

if (!$payload) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$userId = $payload['user_id'];
$action = $input['action'] ?? '';

if ($action === 'create_panel') {
    $eggId = intval($input['egg_id'] ?? 0);
    $ram = intval($input['ram'] ?? 0);
    $hostname = htmlspecialchars($input['hostname'] ?? '');
    $username = htmlspecialchars($input['username'] ?? '');
    $email = filter_var($input['email'] ?? '', FILTER_SANITIZE_EMAIL);

    // Get plan
    $stmt = $conn->prepare("SELECT * FROM plans WHERE ram = ? AND active = 1");
    $stmt->bind_param("i", $ram);
    $stmt->execute();
    $plan = $stmt->get_result()->fetch_assoc();

    if (!$plan) {
        echo json_encode(['success' => false, 'message' => 'Paket tidak valid']);
        exit;
    }

    $fee = calcFee($plan['price']);
    $total = $plan['price'] + $fee;
    $orderId = 'PT-' . strtoupper(bin2hex(random_bytes(3)));
    $expires = date('Y-m-d H:i:s', strtotime('+' . SUBSCRIPTION_DAYS . ' days'));

    // Get active server
    $server = $conn->query("SELECT * FROM servers WHERE status = 'active' ORDER BY id LIMIT 1")->fetch_assoc();
    $serverId = $server ? $server['id'] : null;

    $stmt = $conn->prepare("INSERT INTO orders 
        (order_id, user_id, type, hostname, username, panel_email, egg_id, ram, cpu, disk, swap, amount, fee, total, server_id, expires_at) 
        VALUES (?, ?, 'panel', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sisssiiiiiiiiis", $orderId, $userId, $hostname, $username, $email, $eggId, $ram, $plan['cpu'], $plan['disk'], $plan['swap'], $plan['price'], $fee, $total, $serverId, $expires);
    $stmt->execute();

    // Create Pakasir QRIS
    $pakasirPayload = json_encode([
        'project'  => PAKASIR_PROJECT,
        'order_id' => $orderId,
        'amount'   => $total,
        'api_key'  => PAKASIR_API_KEY
    ]);

    $ch = curl_init('https://app.pakasir.com/api/transactioncreate/qris');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $pakasirPayload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $qrisData = json_decode($response, true);

    if (isset($qrisData['payment']['payment_number'])) {
        $stmt2 = $conn->prepare("UPDATE orders SET payment_number = ? WHERE order_id = ?");
        $stmt2->bind_param("ss", $qrisData['payment']['payment_number'], $orderId);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'total' => $total,
            'qris_string' => $qrisData['payment']['payment_number'],
            'expired_at' => $qrisData['payment']['expired_at'] ?? date('Y-m-d H:i:s', strtotime('+15 minutes'))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal membuat QRIS', 'debug' => $qrisData]);
    }
}

elseif ($action === 'create_script') {
    $scriptId = intval($input['script_id'] ?? 0);
    $botName = htmlspecialchars($input['bot_name'] ?? '');
    $botToken = $input['bot_token'] ?? '';
    $chatId = htmlspecialchars($input['chat_id'] ?? '');

    $stmt = $conn->prepare("SELECT * FROM scripts WHERE id = ? AND active = 1");
    $stmt->bind_param("i", $scriptId);
    $stmt->execute();
    $script = $stmt->get_result()->fetch_assoc();

    if (!$script) {
        echo json_encode(['success' => false, 'message' => 'Script tidak ditemukan']);
        exit;
    }

    $fee = calcFee($script['price']);
    $total = $script['price'] + $fee;
    $orderId = 'SC-' . strtoupper(bin2hex(random_bytes(3)));

    $stmt = $conn->prepare("INSERT INTO orders 
        (order_id, user_id, type, script_id, bot_name, bot_token, chat_id, amount, fee, total) 
        VALUES (?, ?, 'script', ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("siisssiii", $orderId, $userId, $scriptId, $botName, $botToken, $chatId, $script['price'], $fee, $total);
    $stmt->execute();

    // Create Pakasir QRIS
    $pakasirPayload = json_encode([
        'project'  => PAKASIR_PROJECT,
        'order_id' => $orderId,
        'amount'   => $total,
        'api_key'  => PAKASIR_API_KEY
    ]);

    $ch = curl_init('https://app.pakasir.com/api/transactioncreate/qris');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $pakasirPayload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $qrisData = json_decode($response, true);

    if (isset($qrisData['payment']['payment_number'])) {
        $stmt2 = $conn->prepare("UPDATE orders SET payment_number = ? WHERE order_id = ?");
        $stmt2->bind_param("ss", $qrisData['payment']['payment_number'], $orderId);
        $stmt2->execute();

        echo json_encode([
            'success' => true,
            'order_id' => $orderId,
            'total' => $total,
            'qris_string' => $qrisData['payment']['payment_number'],
            'expired_at' => $qrisData['payment']['expired_at'] ?? date('Y-m-d H:i:s', strtotime('+15 minutes'))
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal membuat QRIS']);
    }
}

elseif ($action === 'my_orders') {
    $stmt = $conn->prepare("SELECT o.*, e.name as egg_name, s.name as script_name FROM orders o LEFT JOIN eggs e ON o.egg_id = e.id LEFT JOIN scripts s ON o.script_id = s.id WHERE o.user_id = ? ORDER BY o.created_at DESC");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    echo json_encode(['success' => true, 'orders' => $orders]);
}

elseif ($action === 'check') {
    $orderId = $input['order_id'] ?? '';
    $stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ? AND user_id = ?");
    $stmt->bind_param("si", $orderId, $userId);
    $stmt->execute();
    $order = $stmt->get_result()->fetch_assoc();
    echo json_encode(['success' => true, 'status' => $order['status'] ?? 'not_found', 'order' => $order]);
}
?>
