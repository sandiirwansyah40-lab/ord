<?php
header('Content-Type: application/json');
require 'config.php';

$conn = getDB();
$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? '';

if ($action === 'register') {
    $name = htmlspecialchars($input['name'] ?? '');
    $email = filter_var($input['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $input['password'] ?? '';

    if (!$name || !$email || !$password || strlen($password) < 8) {
        echo json_encode(['success' => false, 'message' => 'Data tidak valid']);
        exit;
    }

    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    if ($stmt->get_result()->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email sudah terdaftar']);
        exit;
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO users (name, email, password_hash) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $hash);

    if ($stmt->execute()) {
        $userId = $stmt->insert_id;
        $token = generateJWT(['user_id' => $userId, 'email' => $email, 'role' => 'user']);
        echo json_encode(['success' => true, 'token' => $token, 'user' => ['id' => $userId, 'name' => $name, 'email' => $email, 'role' => 'user']]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Gagal mendaftar']);
    }
}

elseif ($action === 'login') {
    $email = filter_var($input['email'] ?? '', FILTER_SANITIZE_EMAIL);
    $password = $input['password'] ?? '';

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    if ($user && password_verify($password, $user['password_hash'])) {
        $token = generateJWT(['user_id' => $user['id'], 'email' => $user['email'], 'role' => $user['role']]);
        echo json_encode(['success' => true, 'token' => $token, 'user' => ['id' => $user['id'], 'name' => $user['name'], 'email' => $user['email'], 'role' => $user['role']]]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Email atau password salah']);
    }
}

elseif ($action === 'me') {
    $headers = getallheaders();
    $token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');
    $payload = verifyJWT($token);

    if (!$payload) {
        echo json_encode(['success' => false, 'message' => 'Token tidak valid']);
        exit;
    }

    $stmt = $conn->prepare("SELECT id, name, email, role FROM users WHERE id = ?");
    $stmt->bind_param("i", $payload['user_id']);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();
    echo json_encode(['success' => true, 'user' => $user]);
}
?>
