<?php
require 'config.php';

$conn = getDB();
$payload = json_decode(file_get_contents('php://input'), true);

$amount = $payload['amount'] ?? 0;
$order_id = $payload['order_id'] ?? '';
$project = $payload['project'] ?? '';
$status = $payload['status'] ?? '';
$completed = $payload['completed_at'] ?? '';

if ($project !== PAKASIR_PROJECT) {
    http_response_code(400);
    echo json_encode(['status' => 'invalid_project']);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM orders WHERE order_id = ? AND total = ?");
$stmt->bind_param("si", $order_id, $amount);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();

if (!$order || $status !== 'completed') {
    echo json_encode(['status' => 'ignored']);
    exit;
}

// Update order status
$newStatus = $order['type'] === 'panel' ? 'active' : 'completed';
$expires = date('Y-m-d H:i:s', strtotime('+' . SUBSCRIPTION_DAYS . ' days'));

$stmt2 = $conn->prepare("UPDATE orders SET status = ?, paid_at = ?, expires_at = ? WHERE order_id = ?");
$stmt2->bind_param("ssss", $newStatus, $completed, $expires, $order_id);
$stmt2->execute();

// If panel order, create Pterodactyl server
if ($order['type'] === 'panel') {
    createPterodactylServer($order, $conn);
}

echo json_encode(['status' => 'ok']);

function createPterodactylServer($order, $conn) {
    // Get server
    $server = $conn->query("SELECT * FROM servers WHERE id = " . intval($order['server_id']))->fetch_assoc();
    if (!$server) return;

    // Get egg
    $egg = $conn->query("SELECT * FROM eggs WHERE id = " . intval($order['egg_id']))->fetch_assoc();
    if (!$egg) return;

    // Create user in Pterodactyl first (or use existing)
    $userPayload = json_encode([
        'email' => $order['panel_email'],
        'username' => $order['username'],
        'first_name' => $order['username'],
        'last_name' => 'User',
        'password' => bin2hex(random_bytes(8))
    ]);

    $ch = curl_init($server['url'] . '/api/application/users');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $userPayload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $server['api_key'],
        'Content-Type: application/json',
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $userResponse = curl_exec($ch);
    curl_close($ch);

    $userData = json_decode($userResponse, true);
    $pteroUserId = $userData['attributes']['id'] ?? null;

    if (!$pteroUserId) return;

    // Create server
    $serverPayload = json_encode([
        'name' => $order['hostname'],
        'user' => $pteroUserId,
        'egg' => $egg['pterodactyl_egg_id'],
        'docker_image' => 'ghcr.io/pterodactyl/yolks:java_17',
        'startup' => 'java -Xms128M -XX:MaxRAMPercentage=95.0 -jar {{SERVER_JARFILE}}',
        'environment' => [
            'SERVER_JARFILE' => 'server.jar',
            'BUILD_NUMBER' => 'latest'
        ],
        'limits' => [
            'memory' => $order['ram'] * 1024,
            'swap' => $order['swap'],
            'disk' => $order['disk'],
            'io' => 500,
            'cpu' => $order['cpu']
        ],
        'feature_limits' => [
            'databases' => 1,
            'allocations' => 1,
            'backups' => 1
        ],
        'allocation' => [
            'default' => 1
        ]
    ]);

    $ch = curl_init($server['url'] . '/api/application/servers');
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $serverPayload);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Authorization: Bearer ' . $server['api_key'],
        'Content-Type: application/json',
        'Accept: application/json'
    ]);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    $serverData = json_decode($response, true);
    if (isset($serverData['attributes']['identifier'])) {
        $stmt = $conn->prepare("UPDATE orders SET pterodactyl_server_id = ? WHERE order_id = ?");
        $stmt->bind_param("ss", $serverData['attributes']['identifier'], $order['order_id']);
        $stmt->execute();
    }
}
?>
