<?php
// ─── PAKASIR PAYMENT GATEWAY ───
define('PAKASIR_PROJECT', 'slug-proyek-kamu');
define('PAKASIR_API_KEY',  'api-key-kamu');

// ─── PTERODACTYL PANEL API ───
define('PTERODACTYL_URL',  'https://panel.kamu.com');
define('PTERODACTYL_KEY',  'ptla_xxxxx');

// ─── DATABASE ───
define('DB_HOST', 'localhost');
define('DB_NAME', 'ptero_store');
define('DB_USER', 'root');
define('DB_PASS', 'password');

// ─── APP CONFIG ───
define('JWT_SECRET', 'ganti-dengan-secret-key-yang-kuat-12345');
define('SUBSCRIPTION_DAYS', 30); // Auto delete after 30 days

// ─── HARGA DEFAULT ───
$DEFAULT_PLANS = [
    ['ram' => 1,  'price' => 7000,  'cpu' => 100,  'disk' => 5120,   'swap' => 1024],
    ['ram' => 2,  'price' => 12000, 'cpu' => 150,  'disk' => 10240,  'swap' => 2048],
    ['ram' => 3,  'price' => 17000, 'cpu' => 200,  'disk' => 15360,  'swap' => 3072],
    ['ram' => 4,  'price' => 22000, 'cpu' => 250,  'disk' => 20480,  'swap' => 4096],
    ['ram' => 6,  'price' => 32000, 'cpu' => 300,  'disk' => 30720,  'swap' => 6144],
    ['ram' => 8,  'price' => 42000, 'cpu' => 400,  'disk' => 40960,  'swap' => 8192],
    ['ram' => 12, 'price' => 62000, 'cpu' => 500,  'disk' => 61440,  'swap' => 12288],
    ['ram' => 16, 'price' => 82000, 'cpu' => 600,  'disk' => 81920,  'swap' => 16384],
];

function calcFee($amount) {
    return round($amount * 0.007 + 310);
}

function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        die(json_encode(['success' => false, 'message' => 'DB Error']));
    }
    return $conn;
}

function generateJWT($payload) {
    $header = json_encode(['typ' => 'JWT', 'alg' => 'HS256']);
    $payload['iat'] = time();
    $payload['exp'] = time() + (86400 * 7); // 7 days

    $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
    $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode(json_encode($payload)));

    $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, JWT_SECRET, true);
    $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    return $base64Header . "." . $base64Payload . "." . $base64Signature;
}

function verifyJWT($token) {
    $parts = explode('.', $token);
    if (count($parts) !== 3) return false;

    $signature = hash_hmac('sha256', $parts[0] . "." . $parts[1], JWT_SECRET, true);
    $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));

    if (!hash_equals($base64Signature, $parts[2])) return false;

    $payload = json_decode(base64_decode(str_replace(['-', '_'], ['+', '/'], $parts[1])), true);
    if (!$payload || $payload['exp'] < time()) return false;

    return $payload;
}
?>
